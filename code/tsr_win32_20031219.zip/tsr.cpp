// tsr.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "tsr.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "TsrDoc.h"
#include "TreeView.h"
#include "hyperlink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTsrApp

BEGIN_MESSAGE_MAP(CTsrApp, CWinApp)
	//{{AFX_MSG_MAP(CTsrApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTsrApp construction

CTsrApp::CTsrApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTsrApp object

CTsrApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTsrApp initialization

BOOL CTsrApp::InitInstance(){



	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_TSRTYPE,
		RUNTIME_CLASS(CTsrDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CMyTreeView));
	AddDocTemplate(pDocTemplate);

	pDocTemplate = new CMultiDocTemplate(
		IDR_MUXTYPE,
		RUNTIME_CLASS(CTsrDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CMyTreeView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if(!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// prevent the default child frame at start up
	if(cmdInfo.m_nShellCommand == CCommandLineInfo::FileNew)
		cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(SW_SHOWMAXIMIZED);
	//pMainFrame->ShowWindow(SW_SHOW);
	pMainFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_email;
	CEdit	m_edit;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_HYPER_MAIL, m_email);
	DDX_Control(pDX, IDC_EDIT_ABOUT, m_edit);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CTsrApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CTsrApp commands
static char s_change_log[] = 
"Change Log:\r\n"
"===========\r\n"
"\r\n"
"\r\n"
"2003.12.19: beta 0.2.04\r\n"
"    - Added parse of logical channel descriptor(0x83), courtesy draft std document from Charles Sevior (CSevior@nine.com.au)\r\n"
"    - Added parse of terrestrial_delivery_system_descriptor\r\n"
"\r\n"
"2003.11.05: beta 0.2.03\r\n"
"    - Added feature of Extracting PIDs from TS\r\n"
"    - Made some minor UI modification\r\n"
"\r\n"
"2003.04.27: beta 0.2.02\r\n"
"    - Show all PSI/SI packets (not include ES or NULL PIDs) in PIDs subtree\r\n"
"\r\n"
"2003.02.05: beta 0.2.01\r\n"
"    - UI updates for \"Save as HTML pages\"\r\n"
"\r\n"
"2003.02.03: beta 0.2.0\r\n"
"    - Added \"Save as HTML pages\" feature, support IE only\r\n"
"\r\n"
"2003.01.21:\r\n"
"    - Re-wrote parsing part to decouple from platform-specific UI API\r\n"
"    - Updated AIT descriptors parsing\r\n"
"\r\n"
"2003.01.19:\r\n"
"    - Fixed bug for AIT section parsing\r\n"
"    - Started code clean up and consolidation for easy porting\r\n"
"\r\n"
"2003.01.13:\r\n"
"    - Added initial AIT(MHP) parsing, courtesy sample streams from Mattias Bergstrom (mbergstrom@gist.de)\r\n"
"\r\n"
"2002.10.29:\r\n"
"    - Handled ts file larger then 800M by only process the first 800M data\r\n"
"    - Added \"Defrag\" by delete the broken packet or otvheader at head or tail of ts file\r\n"
"\r\n"
"2002.06.09: alpha 0.1.3\r\n"
"    - Parsed multiple sections in one TS packet\r\n"
"    - Fixed an EIT section ts_id bug\r\n"
"    - Added local_time_offset descriptor\r\n"
"\r\n"
"2002.05.29:\r\n"
"    - Added several dvb-si descriptors parsing\r\n"
"    - Print OpenTV header info if applicable\r\n"
"    - Support TS file does not start at packet boundary\r\n"
"    - Popup information about the ts file before processing\r\n"
"    - Added convertion from 204 byte to 188 byte packets\r\n"
"\r\n"
"2002.05.19:\r\n"
"    - Added UTC time to MJD time conversion\r\n"
"    - Added RST parsing\r\n"
"    - Added several DVB-SI descriptors parsing\r\n"
"\r\n"
"2002.05.18:\r\n"
"    - Added hints when opening unrecognized files\r\n"
"    - Fixed multiple section data bug(EIT/TOT/TDT...)\r\n"
"    - Added ASCII display to several descriptors\r\n"
"    - Added warranty disclaimer: No warranty at all\r\n"
"\r\n"
"2002.05.03: alpha 0.1.2\r\n"
"    - Parse content of all 13818-1 descriptors\r\n"
"    - Added Change Log to this dialog box\r\n"
"\r\n"
"2002.04.25: alpha 0.1.1\r\n"
"    - Fixed HEX view problem(last line was not shown)\r\n"
"    - Added literal names of all PID/descriptors/stream type/etc\r\n"
"\r\n"
"2002.04.22: alpha 0.1 First release for windows\r\n"
"    - Support both 204 and 188 byte packet size\r\n"
"    - Recognize OpenTV MUX file header\r\n"
"    - Support PAT/PMT/NIT/BAT/CAT/SDT/EIT/TOT/TDT\r\n"
"    - HEX view on particular packet/section(dobule clicking the node)\r\n"
"\r\n"
"2002.03.27:\r\n"
"    - Start trial command line interface coding on solaris\r\n";

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_edit.SetWindowText(s_change_log);
	
	m_email.SetURL(_T("mailto:xiongyw@hotmail.com"));
	m_email.SetColours(m_email.GetLinkColour(),m_email.GetLinkColour());
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
