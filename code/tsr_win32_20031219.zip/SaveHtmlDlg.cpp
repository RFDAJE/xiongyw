// SaveHtmlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "tsr.h"
#include "SaveHtmlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSaveHtmlDlg dialog


CSaveHtmlDlg::CSaveHtmlDlg(CWnd* pParent /*=NULL*/, CString strStart /* _T("c:\\") */)
	: CDialog(CSaveHtmlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSaveHtmlDlg)
	m_strPath = strStart; //_T("");
	//}}AFX_DATA_INIT
	//::GetCurrentDirectory(MAX_PATH, m_strPath.GetBuffer(MAX_PATH));
	//m_strPath.ReleaseBuffer();
}


void CSaveHtmlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSaveHtmlDlg)
	DDX_Control(pDX, IDC_BUTTON_BROWSER, m_browse);
	DDX_Control(pDX, IDC_PATH_NAME, m_ctrlPath);
	DDX_Text(pDX, IDC_PATH_NAME, m_strPath);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSaveHtmlDlg, CDialog)
	//{{AFX_MSG_MAP(CSaveHtmlDlg)
	ON_BN_CLICKED(IDC_BUTTON_BROWSER, OnButtonBrowser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSaveHtmlDlg message handlers

#include "PathDialog.h"
void CSaveHtmlDlg::OnButtonBrowser() 
{
	CString strPath;
	CString strYourCaption(_T("Browsing folder"));
	CString strYourTitle(_T("Select a folder for saving html pages:"));

	m_ctrlPath.GetWindowText(strPath);

	CPathDialog dlg(strYourCaption, strYourTitle, strPath);

	if(dlg.DoModal()==IDOK)
	{
		m_ctrlPath.SetWindowText(dlg.GetPathName());
	}	
}

BOOL CSaveHtmlDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	HICON hIconBrowse;
	hIconBrowse = AfxGetApp()->LoadIcon(IDI_FOLDER);

	m_browse.SetIcon(hIconBrowse); 
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSaveHtmlDlg::OnOK() 
{
	CString strPath;
	m_ctrlPath.GetWindowText(strPath);

	if(CPathDialog::MakeSurePathExists(strPath) == 0)
	{
		CDialog::OnOK();
	}
}
