// TextView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInfoView view

class CInfoView : public CEditView
{
protected:
        CInfoView();           // protected constructor used by dynamic creation
        DECLARE_DYNCREATE(CInfoView)

// Attributes
public:
	CTsrDoc* GetDocument();

// Operations
public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CInfoView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
        virtual ~CInfoView();
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

        // Generated message map functions
protected:
        //{{AFX_MSG(CInfoView)
                // NOTE - the ClassWizard will add and remove member functions here.
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};
#ifndef _DEBUG  
inline CTsrDoc* CInfoView::GetDocument()
   { return (CTsrDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
