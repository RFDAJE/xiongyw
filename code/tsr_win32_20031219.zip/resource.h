//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tsr.rc
//
#define DATANUM                         10
#define IDD_ABOUTBOX                    100
#define DATAMAX                         100
#define IDR_GRIDVIEW_TMPL               102
#define IDR_MAINFRAME                   128
#define IDR_TSRTYPE                     129
#define IDB_TAB                         130
#define IDR_MUXTYPE                     130
#define IDD_CHANGE_PID                  137
#define IDD_EXTRACT_PIDS                137
#define IDD_CHOP_TS                     138
#define IDD_SAVE_HTML                   139
#define IDI_FOLDER                      140
#define IDB_CHECK                       141
#define IDD_CHANGE_PIDS                 142
#define IDB_TREE                        145
#define IDC_EDIT_CHANGE_LOG             1001
#define IDC_EDIT_ABOUT                  1002
#define IDC_EDIT1                       1003
#define IDC_EDIT_SAVE_AS                1003
#define IDC_CHOP_EDIT_START             1003
#define IDC_PATH_NAME                   1003
#define IDC_CHANGE_PIDS_PATH            1003
#define IDC_BUTTON1                     1004
#define IDC_BUTTON_BROWSE               1004
#define IDC_BUTTON_BROWSER              1004
#define IDC_CHANGE_PIDS_BROWSE          1004
#define IDC_LIST2                       1006
#define IDC_LIST_AVAILABLE              1006
#define IDC_LIST_CHOOSEN                1008
#define IDC_BUTTON_ADD                  1009
#define IDC_BUTTON_REMOVE               1010
#define IDC_BUTTON_REMOVE_ALL           1011
#define IDC_LIST_CHANGE_PID             1012
#define IDC_EXTRACT_PIDS_LIST           1012
#define IDC_LIST1                       1013
#define IDC_CHANGE_PIDS_LIST            1013
#define IDC_TOTAL_PACKETS               1014
#define IDC_CHOP_SIZE                   1015
#define IDC_CHOP_204TO188               1016
#define IDC_CHOP_EDIT_END               1017
#define IDC_SAVE_AS                     1018
#define IDC_CHOP_SAVE_AS                1019
#define IDC_HYPER_MAIL                  1020
#define ID_MENUITEM32771                32771
#define ID_MENUITEM32772                32772
#define ID_MENUITEM32773                32773
#define ID_GRAPH_DATA1                  32774
#define ID_GRAPH_DATA2                  32775
#define ID_GRAPH_DATA3                  32776
#define ID_204TO188                     32777
#define ID_CHANGE_PID                   32778
#define ID_EXTRACT_PID                  32779
#define ID_DEFRAG                       32780
#define ID_CHOP                         32781
#define ID_FILE_SAVE_HTML               32782
#define ID_EXTRACT_PIDS                 32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
