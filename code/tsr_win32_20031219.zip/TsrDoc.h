// TsrDoc.h : interface of the CTsrDoc class
//
/////////////////////////////////////////////////////////////////////////////


class CTsrDoc : public CDocument
{
protected: // create from serialization only
        CTsrDoc();
        DECLARE_DYNCREATE(CTsrDoc)

// Attributes
public:

	CString        m_sPathName;
	HANDLE         m_hFile;      // handle to file kernel object  
	HANDLE         m_hFileMap;	 // handle to file mapping kernel object

	u8*            m_pFileData;  // point to the beginning of the file
	DWORD          m_nFileSize;  // file size
	
#if (0)	
	u8*            m_pTSData;    // point to the beginning of the TS
    int            m_nTSSize;    // ts size
	bool           m_bOtvHeader; // is there otv header 
	OTV_HEADER     m_otvHeader;  // the otv header
	u8             m_nPacketSize;// 188 or 204
	int            m_nTotalPackets;

	PID_LIST*      m_pid_list;
    
	PMT_LIST       m_pmt_list;
    AIT_LIST       m_ait_list;   /* added(bruin, 2003.01.13) */

	/* tables */

	TABLE*         m_tbl_pat;
	TABLE*         m_tbl_cat;
	TABLE*         m_tbl_nit_act;
	TABLE*         m_tbl_nit_oth;
	TABLE*         m_tbl_sdt_act;
	TABLE*         m_tbl_sdt_oth;
	TABLE*         m_tbl_bat;
	TABLE*         m_tbl_eit_act;
	TABLE*         m_tbl_eit_oth;
	TABLE*         m_tbl_eit_act_sch;
	TABLE*         m_tbl_eit_oth_sch;
	TABLE*         m_tbl_tdt;
	TABLE*         m_tbl_tot;
	TABLE*         m_tbl_rst;
	TABLE*         m_tbl_st;

	/* different from other tables: it's a point to an array of pmt tables,
	   not just one. */
	TABLE**        m_tbl_pmts;
    TABLE**        m_tbl_aits; /* added(bruin, 2003.01.13) */
#endif

	TSR_RESULT*    m_result;

	/* members accessed by CHexView to render */
	u8*            m_pHexData;
	int            m_nHexDataSize;

	/* member accessed by CInfoView to show */
	char           m_pInfo[MAX_INFO_SIZE + 1];





// Operations
public:
#if (0)    
    void ResetAllData();
	int ProcessFileData(u8* pFileData, int nFileSize);
#endif
// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CTsrDoc)
	public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
#if (0)
	const char* GetPidNameByID(u16 pid);
#endif
        virtual ~CTsrDoc();
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
        //{{AFX_MSG(CTsrDoc)
	afx_msg void On204to188();
	afx_msg void OnUpdate204to188(CCmdUI* pCmdUI);
	afx_msg void OnUpdateChangePid(CCmdUI* pCmdUI);
	afx_msg void OnChangePid();
	afx_msg void OnExtractPids();
	afx_msg void OnUpdateExtractPid(CCmdUI* pCmdUI);
	afx_msg void OnDefrag();
	afx_msg void OnUpdateDefrag(CCmdUI* pCmdUI);
	afx_msg void OnChop();
	afx_msg void OnUpdateChop(CCmdUI* pCmdUI);
	afx_msg void OnFileSaveHtml();
	afx_msg void OnUpdateFileSaveHtml(CCmdUI* pCmdUI);
	//}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////


