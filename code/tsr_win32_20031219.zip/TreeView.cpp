// CMyTreeView.cpp : implementation of the CMyTreeView class
//

#include "stdafx.h"
#include "Tsr.h"

#include "TsrDoc.h"
#include "TreeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView

IMPLEMENT_DYNCREATE(CMyTreeView, CTreeView)

BEGIN_MESSAGE_MAP(CMyTreeView, CTreeView)
        //{{AFX_MSG_MAP(CMyTreeView)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	//}}AFX_MSG_MAP
        // Standard printing commands
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView construction/destruction

CMyTreeView::CMyTreeView()
{
        // TODO: add construction code here

}

CMyTreeView::~CMyTreeView()
{
}

BOOL CMyTreeView::PreCreateWindow(CREATESTRUCT& cs){

        // TODO: Modify the Window class or styles here by modifying
        //  the CREATESTRUCT cs
		cs.style |= WS_VISIBLE | WS_TABSTOP | WS_CHILD | WS_BORDER | TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES  | TVS_DISABLEDRAGDROP;
        return CTreeView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView diagnostics

#ifdef _DEBUG
void CMyTreeView::AssertValid() const
{
        CTreeView::AssertValid();
}

void CMyTreeView::Dump(CDumpContext& dc) const
{
        CTreeView::Dump(dc);
}

CTsrDoc* CMyTreeView::GetDocument() // non-debug version is inline
{
        ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTsrDoc)));
        return (CTsrDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMyTreeView message handlers

void CMyTreeView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint){


	u32               nFileSize = GetDocument()->m_nFileSize;

	HTREEITEM         hRoot; // file name
	TVINSERTSTRUCT    tvi;

	this->GetTreeCtrl().DeleteAllItems();

	// root item
	tvi.itemex.mask = TVIF_TEXT | TVIF_PARAM | TVIF_IMAGE | TVIF_SELECTEDIMAGE;	
	tvi.itemex.pszText = "";
	tvi.itemex.cchTextMax = 128;
	tvi.itemex.iImage = 0;
	tvi.itemex.iSelectedImage = 0;
	tvi.itemex.lParam = 0xffffffff;
	tvi.hParent = this->GetTreeCtrl().GetRootItem();
	tvi.hInsertAfter = TVI_LAST;
	hRoot = this->GetTreeCtrl().InsertItem(&tvi);

	CopyNode(hRoot, GetDocument()->m_result->root);
#if (0)    
    FILE* fp = fopen("c:\\work\\tsr\\js\\js\\test.js", "wt");
    output(fp, GetDocument()->m_result->root);

    /* show the root */
    fprintf(fp, "N%08x.init(0, true, \"\");\n", (u32)(GetDocument()->m_result->root));
    fprintf(fp, "N%08x.render(0);\n", (u32)(GetDocument()->m_result->root));
    fprintf(fp, "N%08x.is_shown = true;\n", (u32)(GetDocument()->m_result->root));
    fprintf(fp, "D%08x.style.display = \"block\";\n", (u32)(GetDocument()->m_result->root));

    fclose(fp);
#endif
}

void CMyTreeView::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CTreeCtrl& theTree = this->GetTreeCtrl();
	m_imgTree.Create(IDB_TREE, 16, 1, RGB(192, 192, 192));
	theTree.SetImageList(&m_imgTree, TVSIL_NORMAL);
	theTree.SetFont(CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT))); 
	
}

void CMyTreeView::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult){

	CTreeCtrl& theTree = this->GetTreeCtrl();
	HTREEITEM hItem = theTree.GetSelectedItem();
	TNODE* node = (TNODE*)theTree.GetItemData(hItem);

	if(node->type == NODE_TYPE_SECTION){
		/* data for info view */
		_snprintf(GetDocument()->m_pInfo, MAX_INFO_SIZE, "Section index: %d\r\nsection data size: %d", ((SECTION*)(node->tag))->index, ((SECTION*)(node->tag))->size);

		/* data for hex view */
		GetDocument()->m_pHexData = ((SECTION*)(node->tag))->data;
		GetDocument()->m_nHexDataSize = ((SECTION*)(node->tag))->size;
	}
	else  if(node->type == NODE_TYPE_PACKET){ 

		/* data for info view */

		PACKET_HEADER*    pHeader = (PACKET_HEADER*)(GetDocument()->m_result->ts_data + node->tag * GetDocument()->m_result->packet_size);

		_snprintf(GetDocument()->m_pInfo, MAX_INFO_SIZE, "TS packet %d header(first 4 bytes):\r\n\r\n"
					 "sync byte(8)                    : 0x%02x\r\n"
					 "transport error indicator(1)    : 0x%01x\r\n"
					 "payload unit start indicator(1) : 0x%01x\r\n"
					 "transport priority(1)           : 0x%01x\r\n"
					 "packet identifier(13)           : 0x%04x\r\n"
					 "transport scrambling control(2) : 0x%01x\r\n"
					 "adaptation field control(2)     : 0x%01x\r\n"
					 "continuity counter(4)           : 0x%01x\r\n",
					 node->tag,
					 packet_sync_byte(pHeader),
					 packet_transport_error_indicator(pHeader),
					 packet_payload_unit_start_indicator(pHeader),
					 packet_transport_priority(pHeader),
					 packet_pid(pHeader),
					 packet_transport_scrambling_control(pHeader),
					 packet_adaptation_field_control(pHeader),
					 packet_continuity_counter(pHeader));

		/* data for hex view */
		GetDocument()->m_pHexData = (u8*)pHeader;
		GetDocument()->m_nHexDataSize = GetDocument()->m_result->packet_size;
	}
	else{
		return;
	}

	GetDocument()->UpdateAllViews(this);
	*pResult = 0;
}


void CMyTreeView::CopyNode(HTREEITEM peer, TNODE* node){

	TNODE*         kid;
	HTREEITEM      pal;
	UINT           nMask, nState, nStateMask;
	int            iImage, iSelectedImage;
	
	if(!peer || !node)
		return;

	nMask = TVIF_TEXT | TVIF_PARAM | TVIF_IMAGE | TVIF_SELECTEDIMAGE;	
	switch(node->type){
		case NODE_TYPE_TS_FILE:
			iImage = 0;
			iSelectedImage = 0;
			break;
		case NODE_TYPE_OTV_HINFO:
			iImage = 12;
			iSelectedImage = 12;
			break;
		case NODE_TYPE_PSI_SI:
			iImage = 11;
			iSelectedImage = 11;
			break;
		case NODE_TYPE_TABLE:
			iImage = 9;
			iSelectedImage = 9;
			break;
		case NODE_TYPE_SECTION:
			iImage = 5;
			iSelectedImage = 5;
			break;
		case NODE_TYPE_PROGRAM:
			iImage = 4;
			iSelectedImage = 4;
			break;
		case NODE_TYPE_AUDIO_STREAM:
			iImage = 7;
			iSelectedImage = 7;
			break;
		case NODE_TYPE_VIDEO_STREAM:
			iImage = 6;
			iSelectedImage = 6;
			break;
		case NODE_TYPE_PRIVATE_DATA_STREAM:
			iImage = 8;
			iSelectedImage = 8;
			break;
		case NODE_TYPE_PIDS:
			iImage = 10;
			iSelectedImage = 10;
			break;
		case NODE_TYPE_PID:
			iImage = 3;
			iSelectedImage = 3;
			break;
		case NODE_TYPE_PACKETS:
			iImage = 0;
			iSelectedImage = 0;
			break;
		case NODE_TYPE_PACKET:
			iImage = 1;
			iSelectedImage = 1;
			break;
		case NODE_TYPE_DEFAULT:
		default:
			iImage = 2;
			iSelectedImage = 2;
			break;
	}

    nState = 0;
    nStateMask = 0;
	
	this->GetTreeCtrl().SetItem(peer, nMask, (const char*)(node->txt), iImage, iSelectedImage, nState, nStateMask, 
		(long)node);	/* the lParam of the tree item points to the node */

	if(kid = node->kid){
		while(kid){
			pal = 	this->GetTreeCtrl().InsertItem("", peer, TVI_LAST);
			CopyNode(pal, kid);
			kid = kid->sib;
		}
	}
}

void CMyTreeView::output(FILE* fp, TNODE* node){
    TNODE* kid;
    char   txt[4096], *p;
    int    i, len;
    
    
    if(!fp)
        return;
    
    len = strlen((const char*)(node->txt));
    p = txt;
    for(i = 0; i < len; i ++){
        if(node->txt[i] == '\"' || node->txt[i] == '\\'){
            *p = '\\';
            p += 1;
        }
        *p = node->txt[i];
        p += 1;
    }
    *p = '\0';

    fprintf(fp, "N%08x=new Node(\"%08x\", \"%s\", %d, \"\");\n", (u32)node, (u32)node, txt, node->type);
    if(kid = node->kid){
        while(kid){
            output(fp, kid);
            fprintf(fp, "N%08x.add_kid(N%08x);\n", (u32)node, (u32)kid);
            kid = kid->sib;
        }
    }
}

