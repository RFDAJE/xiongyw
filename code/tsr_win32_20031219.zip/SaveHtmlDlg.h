#if !defined(AFX_SAVEHTMLDLG_H__2260E1AF_41B2_429A_986E_399A563A0550__INCLUDED_)
#define AFX_SAVEHTMLDLG_H__2260E1AF_41B2_429A_986E_399A563A0550__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SaveHtmlDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSaveHtmlDlg dialog

class CSaveHtmlDlg : public CDialog
{
// Construction
public:
	CSaveHtmlDlg(CWnd* pParent = NULL, CString strStart = _T("c:\\"));   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSaveHtmlDlg)
	enum { IDD = IDD_SAVE_HTML };
	CButton	m_browse;
	CEdit	m_ctrlPath;
	CString	m_strPath;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSaveHtmlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSaveHtmlDlg)
	afx_msg void OnButtonBrowser();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAVEHTMLDLG_H__2260E1AF_41B2_429A_986E_399A563A0550__INCLUDED_)
