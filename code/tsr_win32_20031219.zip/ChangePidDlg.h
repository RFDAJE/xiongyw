#if !defined(AFX_CHANGEPIDDLG1_H__391F95C3_3EF6_4EA9_BF51_5B43F83C852A__INCLUDED_)
#define AFX_CHANGEPIDDLG1_H__391F95C3_3EF6_4EA9_BF51_5B43F83C852A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChangePidDlg.h : header file
//
#include "PropertyList.h"
/////////////////////////////////////////////////////////////////////////////
// CChangePidDlg dialog

class CChangePidDlg : public CDialog
{
// Construction
public:
	CChangePidDlg(CTsrDoc* pDoc, CWnd* pParent = NULL);   // standard constructor

	CTsrDoc* m_pDoc;
// Dialog Data
	//{{AFX_DATA(CChangePidDlg)
	enum { IDD = IDD_CHANGE_PIDS };
	CButton	m_browse;
	CEdit	m_ctrlPath;
	CPropertyList	m_list;
	CString	m_strPath;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChangePidDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChangePidDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHANGEPIDDLG1_H__391F95C3_3EF6_4EA9_BF51_5B43F83C852A__INCLUDED_)
