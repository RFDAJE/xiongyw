// tsr.h : main header file for the GRAPH application
//


/*** change log ***/
/* 

2002.04.25:
	- fixed hex view problem(last line does not shown)
	- added descriptor name

2002.04.22:  alpha 0.1 internal release
	- support both 204 and 188 packet size
	- recognize opentv header
	- support pat/pmt/nit/bat/cat/sdt/eit/tot/tdt
	- hex view on particular packet or section (dobule clicking the node)

*/
#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

#include "lib/si.h"
#include "lib/libsi.h"
#include "lib/tree.h"
#include "lib/save_html.h"

#define MAX_INFO_SIZE           4096
#define MAX_HEX_DATA_SIZE       4096
#define BUF_SIZE                MAX_HEX_DATA_SIZE * 4
#define MAX_TS_PACKET           1024
#define MAX_PID_PACKET          16


/////////////////////////////////////////////////////////////////////////////
// CTsrApp:
// See tsr.cpp for the implementation of this class
//

class CTsrApp : public CWinApp
{
public:
	CTsrApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTsrApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTsrApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
