// ChangePidDlg.cpp : implementation file
//

#include "stdafx.h"
#include "tsr.h"
#include "tsrDoc.h"
#include "ChangePidDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChangePidDlg dialog


CChangePidDlg::CChangePidDlg(CTsrDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CChangePidDlg::IDD, pParent)
{
	m_pDoc = pDoc;
	//{{AFX_DATA_INIT(CChangePidDlg)
	m_strPath = _T("");
	//}}AFX_DATA_INIT
}


void CChangePidDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChangePidDlg)
	DDX_Control(pDX, IDC_CHANGE_PIDS_BROWSE, m_browse);
	DDX_Control(pDX, IDC_CHANGE_PIDS_PATH, m_ctrlPath);
	DDX_Control(pDX, IDC_CHANGE_PIDS_LIST, m_list);
	DDX_Text(pDX, IDC_CHANGE_PIDS_PATH, m_strPath);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChangePidDlg, CDialog)
	//{{AFX_MSG_MAP(CChangePidDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChangePidDlg message handlers

BOOL CChangePidDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CPropertyItem *pItem;
	CString       s;
	int           i, j;
	TSR_RESULT     *result;
	PID_NODE       *pid_node;
    const char     *pidname;

	result = m_pDoc->m_result;
	if(!result)
		return FALSE;


	for(i = 0, pid_node = result->pid_list->head; pid_node != 0; pid_node = pid_node->next, i ++){


        pidname = get_pid_name_by_id(pid_node->pid);
        
		if(!pidname){ /* pmt or ait? */

        	for(j = 0; j < result->pmt_list.pmt_nr; j ++)
        		if(result->pmt_list.pmt_pid[j] == pid_node->pid)
        			pidname = "PMT";
                
            for(j = 0; j < result->ait_list.ait_nr; j ++)
                if(result->ait_list.ait_pid[j] == pid_node->pid)
                    pidname = "AIT";
		}
        
		if(!pidname){ /* es */
			pidname = get_stream_type_name_by_id(pid_node->stream_type);
		}

		//s.Format("0x%04x(%d) %s", pid_node->pid, pid_node->pid, pidname);
		s.Format("0x%04x(%d)", pid_node->pid, pid_node->pid);
		pItem = new CPropertyItem(s,"",PIT_EDIT,"");
		m_list.AddPropItem(pItem);
	}

	


	// set icon on the browse button
	HICON hIconBrowse;
	hIconBrowse = AfxGetApp()->LoadIcon(IDI_FOLDER);
	m_browse.SetIcon(hIconBrowse); 

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
