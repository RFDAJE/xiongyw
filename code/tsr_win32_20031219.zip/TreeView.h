// TreeView.h : interface of the CMyTreeView class
//
/////////////////////////////////////////////////////////////////////////////

class CMyTreeView : public CTreeView
{
protected: // create from serialization only
	CMyTreeView();
	DECLARE_DYNCREATE(CMyTreeView)

// Attributes
public:
	CImageList   m_imgTree;
	CTsrDoc* GetDocument();

	void CopyNode(HTREEITEM peer, TNODE* node);
    void output(FILE* fp, TNODE* node);
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTreeView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:

	virtual ~CMyTreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMyTreeView)
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TreeView.cpp
inline CTsrDoc* CMyTreeView::GetDocument()
   { return (CTsrDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
