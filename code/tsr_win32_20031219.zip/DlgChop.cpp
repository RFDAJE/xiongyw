// DlgChop.cpp : implementation file
//

#include "stdafx.h"
#include "tsr.h"
#include "TsrDoc.h"
#include "DlgChop.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChop dialog

CDlgChop::CDlgChop(CTsrDoc* pDoc, CWnd* pParent)
	: CDialog(CDlgChop::IDD, pParent)
{
	m_pDoc = pDoc;

	if(pDoc->m_result->packet_size == 188)
		m_204to188.EnableWindow(FALSE);

	//{{AFX_DATA_INIT(CDlgChop)
	m_sSaveAs = _T("c:\\chop.ts");
	m_chop_size = _T("chop size: ");
	//}}AFX_DATA_INIT
	m_total_packets.Format("total packet number: %d", pDoc->m_result->packet_nr);
		
}


void CDlgChop::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChop)
	DDX_Control(pDX, IDC_CHOP_204TO188, m_204to188);
	DDX_Control(pDX, IDC_CHOP_EDIT_START, m_editStart);
	DDX_Control(pDX, IDC_CHOP_EDIT_END, m_editEnd);
	DDX_Text(pDX, IDC_CHOP_SAVE_AS, m_sSaveAs);
	DDX_Text(pDX, IDC_CHOP_SIZE, m_chop_size);
	DDX_Text(pDX, IDC_TOTAL_PACKETS, m_total_packets);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChop, CDialog)
	//{{AFX_MSG_MAP(CDlgChop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChop message handlers


