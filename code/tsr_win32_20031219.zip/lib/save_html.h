#ifndef __SAVE_HTML__
#define __SAVE_HTML__

#include "libsi.h"

#ifdef __cplusplus
extern "C"{
#endif

int save_as_html(const char* ts_file_path_name, TSR_RESULT* result);

#ifdef __cplusplus
}
#endif

#endif /* __SAVE_HTML__ */
