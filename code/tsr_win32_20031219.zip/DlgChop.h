#if !defined(AFX_DLGCHOP_H__C61AF3B5_8AF2_4CFE_96C8_C38C3E012BD8__INCLUDED_)
#define AFX_DLGCHOP_H__C61AF3B5_8AF2_4CFE_96C8_C38C3E012BD8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgChop.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgChop dialog

class CDlgChop : public CDialog
{
// Construction
public:
	CDlgChop(CTsrDoc* pDoc, CWnd* pParent);   // standard constructor

// Dialog Data
	CTsrDoc* m_pDoc;
	//{{AFX_DATA(CDlgChop)
	enum { IDD = IDD_CHOP_TS };
	CButton	m_204to188;
	CEdit	m_editStart;
	CEdit	m_editEnd;
	CString	m_sSaveAs;
	CString	m_chop_size;
	CString	m_total_packets;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChop)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgChop)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCHOP_H__C61AF3B5_8AF2_4CFE_96C8_C38C3E012BD8__INCLUDED_)
