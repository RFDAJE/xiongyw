// HexView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHexView view

class CHexView : public CEditView
{
protected:
        CHexView();           // protected constructor used by dynamic creation
        DECLARE_DYNCREATE(CHexView)

// Attributes
public:

	CTsrDoc* GetDocument();

// Operations
public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CHexView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
        virtual ~CHexView();
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

        // Generated message map functions
protected:
        //{{AFX_MSG(CHexView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  
inline CTsrDoc* CHexView::GetDocument()
   { return (CTsrDoc*)m_pDocument; }
#endif
/////////////////////////////////////////////////////////////////////////////
