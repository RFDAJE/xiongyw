// TextView.cpp : implementation file
//

#include "stdafx.h"
#include "Tsr.h"
#include "TsrDoc.h"
#include "InfoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInfoView

IMPLEMENT_DYNCREATE(CInfoView, CEditView)

CInfoView::CInfoView()
{
}

CInfoView::~CInfoView()
{
}


BEGIN_MESSAGE_MAP(CInfoView, CEditView)
        //{{AFX_MSG_MAP(CInfoView)
                // NOTE - the ClassWizard will add and remove mapping macros here.
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInfoView drawing



/////////////////////////////////////////////////////////////////////////////
// CInfoView diagnostics

#ifdef _DEBUG
void CInfoView::AssertValid() const
{
        CEditView::AssertValid();
}

void CInfoView::Dump(CDumpContext& dc) const
{
        CEditView::Dump(dc);
}
CTsrDoc* CInfoView::GetDocument() // non-debug version is inline
{
        ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTsrDoc)));
        return (CTsrDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CInfoView message handlers

void CInfoView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	CTsrDoc* pDoc = (CTsrDoc*)GetDocument();

	CEdit& theEdit = GetEditCtrl();
	theEdit.SetSel(0, - 1);
	theEdit.Clear();
	theEdit.SetWindowText(pDoc->m_pInfo);
}

void CInfoView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CEdit& theEdit = GetEditCtrl();
	theEdit.SetReadOnly();
	theEdit.SetFont(CFont::FromHandle((HFONT)GetStockObject(ANSI_FIXED_FONT)));
}
