// BarView.cpp : implementation file
//

#include "stdafx.h"
#include "Tsr.h"

#include "TsrDoc.h"
#include "HexView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHexView


IMPLEMENT_DYNCREATE(CHexView, CEditView)

CHexView::CHexView()
{
}

CHexView::~CHexView(){
}


BEGIN_MESSAGE_MAP(CHexView, CEditView)
        //{{AFX_MSG_MAP(CHexView)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CHexView diagnostics

#ifdef _DEBUG
void CHexView::AssertValid() const
{
        CEditView::AssertValid();
}

void CHexView::Dump(CDumpContext& dc) const
{
        CEditView::Dump(dc);

}
CTsrDoc* CHexView::GetDocument() // non-debug version is inline
{
        ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTsrDoc)));
        return (CTsrDoc*)m_pDocument;
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHexView message handlers

void CHexView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CEdit& theEdit = GetEditCtrl();
	theEdit.SetReadOnly();
	theEdit.SetFont(CFont::FromHandle((HFONT)GetStockObject(ANSI_FIXED_FONT)));
	
}


void CHexView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint){
	// TODO: Add your specialized code here and/or call the base class
	CTsrDoc* pDoc = GetDocument();
	CEdit&   theEdit = GetEditCtrl();
	CRect    rect;
	LOGFONT  lf;
	int      nCharPerLine, nBytePerLine, nRows, i, j;

	if(pDoc->m_nHexDataSize == 0)
		return;

	GetClientRect(rect);
    (CFont::FromHandle((HFONT)GetStockObject(ANSI_FIXED_FONT)))->GetLogFont(&lf);
	nCharPerLine = rect.Width() / lf.lfWidth;
	if(nCharPerLine < 11)
		nCharPerLine = 11;


	/* delete all of the text */
	theEdit.SetSel(0, - 1);
	theEdit.Clear();

	nBytePerLine = nCharPerLine / 4 - 1;
	nRows = (pDoc->m_nHexDataSize - 1) / nBytePerLine + 1;

	u8 *p = pDoc->m_pHexData;
	char c[BUF_SIZE + 1];
	int len = 0;
	for(i = 0; i < nRows - 1; i ++){
		/* offset */
		len += _snprintf(c + len, BUF_SIZE - len, "%04x  ", i * nBytePerLine); 
		/* hex */
		for(j = 0; j < nBytePerLine; j ++)
			len += _snprintf(c + len, BUF_SIZE - len, "%02x ", p[i * nBytePerLine + j]);
		len += _snprintf(c + len, BUF_SIZE - len, " ");
		/* ascii */
		for(j = 0; j < nBytePerLine; j ++)
			len += _snprintf(c + len, BUF_SIZE - len, "%c", (p[i * nBytePerLine + j] > 0x20 && p[i * nBytePerLine + j] < 0x7e)? p[i * nBytePerLine + j]: '.');

		len += _snprintf(c + len, BUF_SIZE - len, "\r\n");
	}

	/* last row */
	int n = pDoc->m_nHexDataSize % nBytePerLine;
	if(n == 0)
		n = nBytePerLine;

	if(n){
		/* offset */
		len += _snprintf(c + len, BUF_SIZE - len, "%04x  ", i * nBytePerLine); 
		/* hex */
		for(j = 0; j < n; j ++)
			len += _snprintf(c + len, BUF_SIZE - len, "%02x ", p[i * nBytePerLine + j]);
		for(j = n; j < nBytePerLine; j ++)
			len += _snprintf(c + len, BUF_SIZE - len, "   ");
		len += _snprintf(c + len, BUF_SIZE - len, " ");
		/* ascii */
		for(j = 0; j < n; j ++)
			len += _snprintf(c + len, BUF_SIZE - len, "%c", (p[i * nBytePerLine + j] > 0x20 && p[i * nBytePerLine + j] < 0x7e)? p[i * nBytePerLine + j]: '.'); 
		len += _snprintf(c + len, BUF_SIZE - len, "\r\n");
	}




	theEdit.SetWindowText(c);
		

}

void CHexView::OnSize(UINT nType, int cx, int cy){
	CEditView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	OnUpdate(0, 0, 0);

	
}
