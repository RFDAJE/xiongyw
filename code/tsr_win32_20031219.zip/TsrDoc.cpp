// TsrDoc.cpp : implementation of the CTsrDoc class
//

#include "stdafx.h"
#include "Tsr.h"



#include "TsrDoc.h"
#include "SaveHtmlDlg.h"
#include "ExtractPidDlg.h"
#include "ChangePidDlg.h"
#include "DlgChop.h"
#include <direct.h> /* _mkdir() */

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTsrDoc

IMPLEMENT_DYNCREATE(CTsrDoc, CDocument)

BEGIN_MESSAGE_MAP(CTsrDoc, CDocument)
        //{{AFX_MSG_MAP(CTsrDoc)
	ON_COMMAND(ID_204TO188, On204to188)
	ON_UPDATE_COMMAND_UI(ID_204TO188, OnUpdate204to188)
	ON_UPDATE_COMMAND_UI(ID_CHANGE_PID, OnUpdateChangePid)
	ON_COMMAND(ID_CHANGE_PID, OnChangePid)
	ON_COMMAND(ID_EXTRACT_PIDS, OnExtractPids)
	ON_UPDATE_COMMAND_UI(ID_EXTRACT_PIDS, OnUpdateExtractPid)
	ON_COMMAND(ID_DEFRAG, OnDefrag)
	ON_UPDATE_COMMAND_UI(ID_DEFRAG, OnUpdateDefrag)
	ON_COMMAND(ID_CHOP, OnChop)
	ON_UPDATE_COMMAND_UI(ID_CHOP, OnUpdateChop)
	ON_COMMAND(ID_FILE_SAVE_HTML, OnFileSaveHtml)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_HTML, OnUpdateFileSaveHtml)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTsrDoc construction/destruction

CTsrDoc::CTsrDoc(){

    m_sPathName.Empty();
	m_hFile = 0;
	m_hFileMap = 0;
	m_pFileData = 0;
    m_nFileSize = 0;

    m_result = 0;
    
	m_pHexData = 0;
	m_nHexDataSize = 0;
	m_pInfo[0] = '\0';
}

CTsrDoc::~CTsrDoc(){
    
}


/////////////////////////////////////////////////////////////////////////////
// CTsrDoc diagnostics

#ifdef _DEBUG
void CTsrDoc::AssertValid() const
{
        CDocument::AssertValid();
}

void CTsrDoc::Dump(CDumpContext& dc) const
{
        CDocument::Dump(dc);
}
#endif //_DEBUG




BOOL CTsrDoc::OnOpenDocument(LPCTSTR lpszPathName){

#define MAX_TS_FILE_SIZE  (800 * 1024 * 1024)  /* 800M byte */

	m_sPathName.Format("%s", lpszPathName);


	/* memory map the file */
	// Open the ts file to be mapped
	m_hFile = CreateFile(lpszPathName,                // file name
	                     GENERIC_READ ,               // access mode: read only
	  				     0,	                          // share mode: cannot shared
						 NULL,                        // Security Attributes 
						 OPEN_EXISTING, 			  // creation distribution
						 FILE_ATTRIBUTE_NORMAL,       // Flags And Attributes 
						 NULL);						  // hTemplateFile: must be NULL under Win95 
	if(m_hFile == INVALID_HANDLE_VALUE){
		AfxMessageBox("Open file failed. please check file share violation etc.");
		return FALSE;
	}

	// get file size
	m_nFileSize = GetFileSize(m_hFile, NULL);
	if(m_nFileSize == INVALID_FILE_SIZE){
		CloseHandle(m_hFile);
		//CloseHandle(m_hFileMap);
		AfxMessageBox("GetFileSize() fail.");
		m_sPathName.Empty();
		return FALSE;
	}

	if(m_nFileSize == 0){
		CloseHandle(m_hFile);
		//CloseHandle(m_hFileMap);
		AfxMessageBox("File size is zero, quit.");
		m_sPathName.Empty();
		return FALSE;
	}

	if(m_nFileSize > MAX_TS_FILE_SIZE){
		if(AfxMessageBox("File size bigger then 800M byte, only the first 800M will be processed.\r\ncontinue?", MB_YESNO | MB_ICONINFORMATION) == IDNO){
			m_sPathName.Empty();
			return FALSE;
		}
		else{
			m_nFileSize = MAX_TS_FILE_SIZE;
		}
	}

	// Create a file-mapping object for the file
	m_hFileMap = CreateFileMapping(m_hFile,            // handle to file to map
		                           NULL, 			   // optional security attributes
		  					       PAGE_READONLY,      // protection for mapping object
								   0,                  // high-order 32 bits of object size
								   0,                  // low-order 32 bits of object size
								   NULL);              // name of file-mapping object
	if (m_hFileMap == NULL){
		CloseHandle(m_hFile);
		m_sPathName.Empty();
		AfxMessageBox("CreateFileMapping() failed.");
		return FALSE;
	}

	// Map the entire file
	m_pFileData = (u8*)MapViewOfFile(m_hFileMap,       // file-mapping object to map into address space 
	                                   FILE_MAP_READ,    // access mode : read only
                                       0,                // high-order 32 bits of file offset 
			  	  					   0,                // low-order 32 bits of file offset 
									   m_nFileSize);     // number of bytes to map: map the entire file 
	if(m_pFileData == NULL){
		char c[128];
		CloseHandle(m_hFile);
		CloseHandle(m_hFileMap);
		m_sPathName.Empty();
		sprintf(c, "MapViewOfFile() fail. GetLastError()= %d\n", GetLastError());
		AfxMessageBox(c);
		return FALSE;
	}

    m_result = build_tsr_result(LPCTSTR(m_sPathName), m_pFileData, m_nFileSize);

	if(m_result == 0){
		AfxMessageBox("Unrecognized file format.", MB_ICONSTOP|MB_OK);

        if(m_pFileData){
            UnmapViewOfFile(m_pFileData);
            m_pFileData = 0;
        }
        
        if(m_hFileMap){
            CloseHandle(m_hFileMap);
            m_hFileMap = 0;
        }
        
        if(m_hFile){
            CloseHandle(m_hFile);
            m_hFile = 0;
        }
        
        m_sPathName.Empty();
        m_nFileSize = 0;
        
        return FALSE;
	}


	UpdateAllViews(NULL);
	
	return TRUE;
}

void CTsrDoc::OnCloseDocument() 
{
    if(m_result)
        delete_tsr_result(m_result);
	
    m_sPathName.Empty();
	if(m_pFileData){
	 	CloseHandle(m_hFile);
		CloseHandle(m_hFileMap);
		m_pFileData = 0;
        m_nFileSize = 0;

	}
	
	CDocument::OnCloseDocument();
}

void CTsrDoc::On204to188(){
	CFileDialog dlgFile(FALSE, "ts", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "TS files (*.ts)|*.ts");

	if(dlgFile.DoModal() == IDOK){

		FILE* fp = fopen(dlgFile.GetPathName(), "wb");
		if(!fp){
			AfxMessageBox("Open file to write fail.");
			return;
		}

		for(unsigned int i = 0; i < m_result->packet_nr; i ++)
			fwrite(m_result->ts_data + m_result->packet_size * i, 188, 1, fp);
		fclose(fp);
	}
}

void CTsrDoc::OnUpdate204to188(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_result->packet_size == 204);
}

void CTsrDoc::OnUpdateChangePid(CCmdUI* pCmdUI){
	pCmdUI->Enable(1);	
}

void CTsrDoc::OnChangePid(){

	CChangePidDlg dlg(this, NULL);
	dlg.DoModal();
	// AfxMessageBox("under construction");
	
}

void CTsrDoc::OnExtractPids(){
	//AfxMessageBox("under construction");
	CExtractPidDlg dlg(this, NULL);

	dlg.DoModal();
	
}

void CTsrDoc::OnUpdateExtractPid(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_result->pid_list->pid_nr > 1);	
}

void CTsrDoc::OnDefrag(){

	CFileDialog dlgFile(FALSE, "ts", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "ts files (*.ts)|*.ts");

	if(dlgFile.DoModal() == IDOK){

		FILE* fp = fopen(dlgFile.GetPathName(), "wb");
		if(!fp){
			AfxMessageBox("Open file for writing failed.");
			return;
		}

		fwrite(m_result->ts_data, m_result->packet_size * m_result->packet_nr, 1, fp);
		fclose(fp);
	}	
}

void CTsrDoc::OnUpdateDefrag(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_result->file_data != m_result->ts_data);
}

void CTsrDoc::OnChop(){
	CDlgChop dlg(this, NULL);
	dlg.DoModal();	
}

void CTsrDoc::OnUpdateChop(CCmdUI* pCmdUI){
	pCmdUI->Enable(FALSE);
}


void CTsrDoc::OnFileSaveHtml(){
	//CDirDialog	dlg;
	//if(dlg.DoBrowse(NULL) == TRUE){
	CSaveHtmlDlg dlg(NULL, m_sPathName.Left(m_sPathName.ReverseFind('\\')));
	if(dlg.DoModal() == TRUE){
		CFileStatus status;
		char        prompt[256];
		char        path[200];


		::SetCursor(LoadCursor(NULL, IDC_WAIT));

		// mkdir if not exist: images/js/packets/sections

		/* images */
		sprintf(path, "%s\\images", dlg.m_strPath);
		if(CFile::GetStatus(path, status) && status.m_attribute == FILE_ATTRIBUTE_DIRECTORY){
			//  directory exists, do nothing
		}
		else{
			if(CreateDirectory(path, NULL) == 0){
				sprintf(prompt, "CreateDirectory(%s) fail.", path);
				AfxMessageBox(prompt);
				return;
			}
		}

		/* js */
		sprintf(path, "%s\\js", dlg.m_strPath);
		if(CFile::GetStatus(path, status) && status.m_attribute == FILE_ATTRIBUTE_DIRECTORY){
			//  directory exists, do nothing
		}
		else{
			if(CreateDirectory(path, NULL) == 0){
				sprintf(prompt, "CreateDirectory(%s) fail.", path);
				AfxMessageBox(prompt);
				return;
			}
		}

		/* packets */
		sprintf(path, "%s\\packets", dlg.m_strPath);
		if(CFile::GetStatus(path, status) && status.m_attribute == FILE_ATTRIBUTE_DIRECTORY){
			//  directory exists, do nothing
		}
		else{
			if(CreateDirectory(path, NULL) == 0){
				sprintf(prompt, "CreateDirectory(%s) fail.", path);
				AfxMessageBox(prompt);
				return;
			}
		}

		/* sections */
		sprintf(path, "%s\\sections", dlg.m_strPath);
		if(CFile::GetStatus(path, status) && status.m_attribute == FILE_ATTRIBUTE_DIRECTORY){
			//  directory exists, do nothing
		}
		else{
			if(CreateDirectory(path, NULL) == 0){
				sprintf(prompt, "CreateDirectory(%s) fail.", path);
				AfxMessageBox(prompt);
				return;
			}
		}

		// save the current working directory
		CString curDir;
		::GetCurrentDirectory(MAX_PATH, curDir.GetBuffer(MAX_PATH));
		curDir.ReleaseBuffer();

		// change to the saving folder directory
		_chdir((LPCTSTR)(dlg.m_strPath));

		if(0 == save_as_html((LPCTSTR)m_sPathName, m_result)){
            // success
            if(IDYES == AfxMessageBox("HTML files saved successfully. \r\nDo you want to view them now?", MB_ICONINFORMATION | MB_YESNO)){
                char url[1024];
                sprintf(url, "%s/index.html", (LPCTSTR)(dlg.m_strPath));
                ShellExecute(NULL, _T("open"), url, NULL,NULL, SW_SHOW);
            }
		}
        else{
            // failure
			AfxMessageBox("Failed when saving html files!", MB_ICONEXCLAMATION);
        }

		// change it back
		_chdir((LPCTSTR)(curDir));

	}
}

void CTsrDoc::OnUpdateFileSaveHtml(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_result != NULL);
}
