// ExtractPidDlg.cpp : implementation file
//

#include "stdafx.h"
#include "tsr.h"
#include "TsrDoc.h"
#include "ExtractPidDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



#define NUM_COLUMNS    4
#define UN_CHECKED     1    // for state image index
#define CHECKED        2

static _TCHAR *_szColumnLabel[NUM_COLUMNS] = {
	_T(" "),          // checkbox image
	_T("PID"), 
	_T("Type"),
	_T("Packets(%)") 
};


static int _nColumnFmt[NUM_COLUMNS] = {
	LVCFMT_LEFT, 
	LVCFMT_LEFT, 
	LVCFMT_LEFT, 
	LVCFMT_LEFT
};

static int _nColumnWidth[NUM_COLUMNS] = {
	22, 92, 200, 100
};


/////////////////////////////////////////////////////////////////////////////
// CExtractPidDlg dialog


CExtractPidDlg::CExtractPidDlg(CTsrDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CExtractPidDlg::IDD, pParent)
{
	m_pDoc = pDoc;
	//{{AFX_DATA_INIT(CExtractPidDlg)
	m_strPath = m_pDoc->m_sPathName + CString(".2");
	//}}AFX_DATA_INIT
}


void CExtractPidDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExtractPidDlg)
	DDX_Control(pDX, IDC_EDIT_SAVE_AS, m_ctrlPath);
	DDX_Control(pDX, IDC_LIST_CHANGE_PID, m_list);
	DDX_Control(pDX, IDC_BUTTON_BROWSE, m_browse);
	DDX_Text(pDX, IDC_EDIT_SAVE_AS, m_strPath);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExtractPidDlg, CDialog)
	//{{AFX_MSG_MAP(CExtractPidDlg)
	ON_NOTIFY(NM_CLICK, IDC_EXTRACT_PIDS_LIST, OnClickPidList)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExtractPidDlg message handlers

BOOL CExtractPidDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	//ListView_SetExtendedListViewStyle(m_list, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

	// set image lists
	m_stateImage.Create(IDB_CHECK, 16, 1, RGB(192, 192, 192));
	m_list.SetImageList(&m_stateImage, LVSIL_STATE);

	// insert columns	
	int       i, j;
	LV_COLUMN lvc;
	CString   s; 

	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;

	for(i = 0; i<NUM_COLUMNS; i++){
		lvc.iSubItem = i;
		lvc.pszText = _szColumnLabel[i];
		lvc.cx = _nColumnWidth[i];
		lvc.fmt = _nColumnFmt[i];
		m_list.InsertColumn(i,&lvc);
	}

	// insert items
	TSR_RESULT     *result;
	PID_NODE       *pid_node;
    const char     *pidname;

	result = m_pDoc->m_result;
	if(!result)
		return FALSE;


	LV_ITEM lvi;

	lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_STATE;
	lvi.iSubItem = 0;
	lvi.pszText = "";
	lvi.stateMask = LVIS_STATEIMAGEMASK;
	lvi.state = INDEXTOSTATEIMAGEMASK(UN_CHECKED);

	for(i = 0, pid_node = result->pid_list->head; pid_node != 0; pid_node = pid_node->next, i ++){


        pidname = get_pid_name_by_id(pid_node->pid);
        
		if(!pidname){ /* pmt or ait? */

        	for(j = 0; j < result->pmt_list.pmt_nr; j ++)
        		if(result->pmt_list.pmt_pid[j] == pid_node->pid)
        			pidname = "PMT";
                
            for(j = 0; j < result->ait_list.ait_nr; j ++)
                if(result->ait_list.ait_pid[j] == pid_node->pid)
                    pidname = "AIT";
		}
        
		if(!pidname){ /* es */
			pidname = get_stream_type_name_by_id(pid_node->stream_type);
		}

		lvi.iItem = i;
		m_list.InsertItem(&lvi);

		m_list.SetItemText(i, 0, "");

		s.Format("0x%04x(%d)", pid_node->pid, pid_node->pid);
		m_list.SetItemText(i, 1, s);

		s.Format("%s", pidname?pidname:"UNKNOWN");
		m_list.SetItemText(i, 2, s);

		s.Format("%d(%.2f%%)", pid_node->packet_nr, pid_node->packet_nr * 100.0 / result->packet_nr);
		m_list.SetItemText(i, 3, s);
	}


	
	// set icon on the browse button
	HICON hIconBrowse;
	hIconBrowse = AfxGetApp()->LoadIcon(IDI_FOLDER);
	m_browse.SetIcon(hIconBrowse); 
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE	

}

void CExtractPidDlg::OnClickPidList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	LPNMLISTVIEW p = (LPNMLISTVIEW)pNMHDR;
	// toggle the state
	if(p->iItem != - 1){
		if((m_list.GetItemState(p->iItem, LVIS_STATEIMAGEMASK) >> 12) == UN_CHECKED){
			m_list.SetItemState(p->iItem, INDEXTOSTATEIMAGEMASK(CHECKED),  LVIS_STATEIMAGEMASK);
		}
		else if((m_list.GetItemState(p->iItem, LVIS_STATEIMAGEMASK) >> 12) == CHECKED){
			m_list.SetItemState(p->iItem, INDEXTOSTATEIMAGEMASK(UN_CHECKED),  LVIS_STATEIMAGEMASK);
		}
	}
	*pResult = 0;
}

void CExtractPidDlg::OnOK() 
{
	// TODO: Add extra validation here
	TSR_RESULT       *result;
	PID_NODE         *pid_node;	
	unsigned char    *p;
	CArray<int, int> pids;
	int              nr_pids, pid;
	int              i, j, match;


	result = m_pDoc->m_result;
	if(!result)
		return;

	::SetCursor(LoadCursor(NULL, IDC_WAIT));


	pids.RemoveAll();
	nr_pids = 0;     //  for sake of performance, instead of using CArray.GetSize() 
	for(i = 0, pid_node = result->pid_list->head; pid_node != 0; pid_node = pid_node->next, i ++){
		if((m_list.GetItemState(i, LVIS_STATEIMAGEMASK) >> 12) == CHECKED){
			pids.Add(pid_node->pid);
			nr_pids ++;
		}
	}

	if(nr_pids == 0){
		if(IDYES == AfxMessageBox("No PID been selected. \r\nDo you want to select again?", MB_ICONINFORMATION | MB_YESNO)){
			return;
		}
		else{
			CDialog::OnOK();
			return;
		}
	}

	m_ctrlPath.GetWindowText(m_strPath);
	FILE* fp = fopen(m_strPath, "wb");
	if(!fp){
		AfxMessageBox("Open file for writing failed.");
		return;
	}

	for(i = 0; i < result->packet_nr; i ++){
		p = (unsigned char*)(result->ts_data + result->packet_size * i);
		pid = packet_pid(p);
		match = 0;
		for(j = 0; j < nr_pids; j ++){
			if(pid == pids[j]){
				match = 1;
				break;
			}
		}
		if(match){
			fwrite(p, result->packet_size, 1, fp);
		}
	}

	fclose(fp);


	pids.RemoveAll();
	::SetCursor(LoadCursor(NULL, IDC_ARROW));

	CDialog::OnOK();
}

void CExtractPidDlg::OnButtonBrowse() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(FALSE, "ts", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"TS files (*.ts)|*.ts|Mux files (*.mux)|*.mux|All files (*.*)|*.*||");

	if(dlg.DoModal()==IDOK){
		m_ctrlPath.SetWindowText(dlg.GetPathName());
	}		
}
